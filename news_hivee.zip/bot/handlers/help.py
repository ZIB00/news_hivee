# bot/handlers/help.py
from aiogram import Router, types, F
from aiogram.filters import Command

router = Router()

@router.message(F.text == "❓ Помощь")
@router.message(Command("help"))
async def cmd_help(message: types.Message):
    await message.answer(
        "🤖 <b>Доступные команды и функции:</b>\n\n"
        "📰 <b>Получить дайджест</b> — свежие новости в выбранном стиле\n"
        "⚙️ <b>Настройки</b> — выбрать «Краткий» или «Полный» формат\n"
        "🔍 <b>Поиск по тегу</b> — найдите новости по теме\n\n"
        "📌 <b>Пример поиска:</b>\n"
        "<code>/search военная_операция</code>\n"
        "<code>/search российские_футболисты</code>\n\n"
        "💡 Теги состоят из слов через подчёркивание. Их можно увидеть в конце <b>Полного</b> дайджеста.",
        parse_mode="HTML"
    )