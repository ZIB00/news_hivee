# services/news_search.py
import sqlite3
from database import get_db_connection

def search_news_by_tag(tag: str, limit: int = 5) -> list[str]:
    """Возвращает список rendered_text по тегу (без учёта регистра)"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute("""
        SELECT pn.rendered_text
        FROM news_tags nt
        JOIN raw_news rn ON nt.news_id = rn.id
        JOIN processed_news pn ON rn.id = pn.id
        WHERE nt.tag = ?
        ORDER BY rn.fetched_at DESC
        LIMIT ?
    """, (tag.lower(), limit))
    
    rows = cursor.fetchall()
    conn.close()
    
    return [row[0] for row in rows if row[0]]