# services/news_loader.py
import feedparser
import json
import os
import asyncio
import aiohttp
from datetime import datetime, timedelta
from trafilatura import fetch_url, extract

async def fetch_raw_news_sample() -> list[dict]:
    """
    Загружает последние новости из RSS-лент, указанных в data/sources.json,
    и извлекает полный текст каждой статьи с помощью trafilatura.
    """
    sources_path = "data/sources.json"
    if not os.path.exists(sources_path):
        # Fallback: тестовая новость
        return [{
            "url": "https://lenta.ru/news/2025/12/06/test",
            "raw_text": "Тестовая новость.\n\nЭто полный текст статьи для демонстрации работы агентов."
        }]

    with open(sources_path, "r", encoding="utf-8") as f:
        sources = json.load(f)["sources"]

    all_entries = []
    connector = aiohttp.TCPConnector(limit=10)
    timeout = aiohttp.ClientTimeout(total=15)

    async with aiohttp.ClientSession(connector=connector, timeout=timeout) as session:
        for source in sources:
            try:
                feed = feedparser.parse(source["rss_url"])
                for entry in feed.entries[:2]:  # макс. 2 статьи на источник
                    if hasattr(entry, 'published_parsed'):
                        pub_date = datetime(*entry.published_parsed[:6])
                        if datetime.utcnow() - pub_date > timedelta(days=1):
                            continue

                    url = entry.link
                    title = getattr(entry, 'title', 'Без заголовка')

                    # Извлекаем полный текст статьи
                    loop = asyncio.get_event_loop()
                    try:
                        html = await loop.run_in_executor(None, fetch_url, url)
                        if html:
                            body = extract(
                                html,
                                include_comments=False,
                                include_tables=False,
                                no_fallback=False,
                                with_metadata=False
                            )
                        else:
                            body = None
                    except Exception as e:
                        print(f"[trafilatura] Ошибка при загрузке {url}: {e}")
                        body = None

                    # Если trafilatura не сработала — используем summary из RSS
                    if not body:
                        body = getattr(entry, 'summary', '') or getattr(entry, 'description', '')

                    # Собираем raw_text как "заголовок + текст"
                    raw_text = f"{title}\n\n{body}".strip()

                    all_entries.append({
                        "url": url,
                        "raw_text": raw_text
                    })

                    if len(all_entries) >= 3:  # макс. 3 новости всего
                        return all_entries

            except Exception as e:
                print(f"[feedparser] Ошибка парсинга {source.get('rss_url', 'unknown')}: {e}")
                continue

    return all_entries[:3]